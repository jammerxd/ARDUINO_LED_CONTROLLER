/*
 Name:		MSGEQ7Lib.cpp
 Created:	8/16/2016 8:12:06 PM
 Author:	jammerxd
 Editor:	http://www.visualmicro.com
*/

#include "MSGEQ7Lib.h"


MSGEQ7::MSGEQ7() {
	MSGEQ7::isInitialized = false;
	MSGEQ7::filterValue = 60;
}
MSGEQ7::~MSGEQ7() {
	MSGEQ7::isInitialized = false;
	MSGEQ7::filterValue = 60;
}
boolean MSGEQ7::Initialize(int strobePin, int resetPin, int dataPin) {
	if (strobePin != resetPin && strobePin != dataPin && resetPin != dataPin && MSGEQ7::filterValue >= 0) {
		MSGEQ7::strobePin = strobePin;
		MSGEQ7::resetPin = resetPin;
		MSGEQ7::dataPin = dataPin;

		pinMode(MSGEQ7::dataPin, OUTPUT);
		pinMode(MSGEQ7::resetPin, OUTPUT);
		pinMode(MSGEQ7::strobePin, OUTPUT);
		analogReference(DEFAULT);

		digitalWrite(MSGEQ7::resetPin, LOW);
		digitalWrite(MSGEQ7::strobePin, HIGH);
		MSGEQ7::isInitialized = true;
	}
	else
	{
		MSGEQ7::isInitialized = false;
	}
	return MSGEQ7::isInitialized;
}
void MSGEQ7::Read(int spectrumValues[])
{
	digitalWrite(MSGEQ7::resetPin, LOW);
	digitalWrite(MSGEQ7::strobePin, HIGH);

	for (int i = 0; i < 7; i++)
	{
		digitalWrite(MSGEQ7::strobePin, LOW);
		
		delayMicroseconds(30);

		spectrumValues[i] = map(constrain(analogRead(MSGEQ7::dataPin), MSGEQ7::filterValue,1023), MSGEQ7::filterValue, 1023, 0, 255);

		digitalWrite(MSGEQ7::strobePin, HIGH);
	}
}



