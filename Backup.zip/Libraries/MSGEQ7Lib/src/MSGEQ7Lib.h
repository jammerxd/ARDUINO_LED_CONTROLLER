/*
 Name:		MSGEQ7Lib.h
 Created:	8/16/2016 8:12:06 PM
 Author:	jammerxd
 Editor:	http://www.visualmicro.com
*/

#ifndef _MSGEQ7Lib_h
#define _MSGEQ7Lib_h

#if defined(ARDUINO) && ARDUINO >= 100
	#include "arduino.h"
#else
	#include "WProgram.h"
#endif

class MSGEQ7 {
public:
	MSGEQ7();
	~MSGEQ7();
	boolean Initialize(int strobePin, int resetPin, int dataPin);
    void Read(int spectrumValues[]);
	int spectrumValues[7];
	int strobePin;
	int resetPin;
	int dataPin;
	int filterValue;//default: 60 - recommended 60-80
private:
	boolean isInitialized;
};

#endif


